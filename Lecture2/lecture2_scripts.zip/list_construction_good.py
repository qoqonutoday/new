newlist = [x**2 for x in range(1,11) if x % 2]
print(newlist)
