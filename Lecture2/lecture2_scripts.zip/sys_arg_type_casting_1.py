import sys

assert(len(sys.argv) == 2), "Expected an argument"
value = sys.argv[1]
print(value + 25)
