import sys
import argparse

assert(len(sys.argv) == 2), " Give me an argument!"
value = sys.argv[1]
print("You provided", value)
