#! /usr/bin/env python3

a = 2
b = 3
result = a + b

print('The result is ', result)

