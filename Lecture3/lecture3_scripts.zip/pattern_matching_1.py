name = 'YBR007C'
dna = 'TAATAAAAAACGCGTTGTCG'
if 'ACGCGT' in dna:
    print('%s has MCB!' % name)
