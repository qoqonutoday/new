def donothing() : 
    k = 5

k = 0
donothing()

print("k = " + str(k))
