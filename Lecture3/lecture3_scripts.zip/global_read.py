f2 = open("sequence.txt", "r") 
bigstring = f2.read()
print(bigstring)
f2.close() # not required
