newlist = []
for x in range(1,11):
    if x % 2:
        newlist.append(x**2)

print(newlist)
