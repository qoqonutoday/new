f = lambda x: (x-3)**2

print( f( 5 ) )
