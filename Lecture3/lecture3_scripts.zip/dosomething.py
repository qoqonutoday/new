def dosomething() : 
    global k
    k = 5

k = 0
dosomething()

print("k = " + str(k))
