#twofunctions.py
""" This module contains two functions
"""
def celsius (temperature) :
    return (temperature - 32)*5/9
def fahrenheit (temperature) :
    return (temperature*9/5 + 32)
