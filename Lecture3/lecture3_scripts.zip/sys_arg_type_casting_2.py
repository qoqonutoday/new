import sys

assert(len(sys.argv) == 2), "Expected an argument"
value = sys.argv[1]
print(float(value) + 25)
