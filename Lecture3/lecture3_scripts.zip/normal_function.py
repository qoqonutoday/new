def f(x):
    return (x-3)**2

print( f(5) )
