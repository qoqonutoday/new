import sys

value = sys.argv[1]
print("You provided", value)
