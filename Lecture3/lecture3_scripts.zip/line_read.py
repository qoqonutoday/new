f3 = open("sequence.txt", "r") 
for line in f3 : # do not forget the column
	print(line)
f3.close() # not required
