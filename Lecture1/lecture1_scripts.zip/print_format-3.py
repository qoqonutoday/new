print("This is {}.".format(25))
print("This is {} and {}.".format(25,30))

print("This is %d."%25)
print("This is %i and %d."%(25,30))
