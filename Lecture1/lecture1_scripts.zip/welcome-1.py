print( "Welcome to the Wonderful World of Bioinformatics!", end='\n' )
print( "Welcome to the Wonderful World of Bioinformatics!", end=':' )
print( "Welcome to the Wonderful World of Bioinformatics!" )
