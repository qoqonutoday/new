print("The \\sign \n can \t also \t be \t printed.")

print("He said: \"Hello\".")
#print("He said: "Hello".")
print('He said: "Hello".')
