x = 14
y = 3
print("Sum: ", x + y)
print("Product: ", x * y)
print("Remainder: ", x % y)
