#!/usr/bin/env python3

x=3
print(x)

x="ACGCGT"
print(x)

