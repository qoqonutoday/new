print("My name is {}.".format("Luka"))

myName="Khan"
print("My name is {}.".format(myName))
