myFloat= 4545.4542244
print("Print the full float: {},\ncutoff to 2 decimals: {:.2f}, \nor large with 1 decimal:  {:10.1f}.".format(myFloat, myFloat, myFloat))
