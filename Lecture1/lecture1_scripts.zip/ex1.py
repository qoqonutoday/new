#sum up all the numbers in [3,7,10,4,-1,0]

list = [3,7,10,4,-1,0]
print( list )
print( 'sum : ', sum( list ) )
