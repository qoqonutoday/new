x = 5
print("x started as ", x)
x = x * 2
print("Then x was ", x)
x = x + 1
print("Finally x was ",x)
