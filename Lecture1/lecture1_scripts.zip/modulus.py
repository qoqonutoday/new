print(5 % 2) # prints a '1' on a line.
print(4 % 2) # prints a '0' on a line.
print(7 % 4) # prints a '3' on a line.
