#!/usr/bin/env python

# The 'tentimes' program 
# a (Python) program,
# which stops after ten iterations.

HOWMANY = 10
count = 0
while ( count < HOWMANY ):
    count = count + 1

    print( "Welcome to the Wonderful World of Bioinformatics!" )
