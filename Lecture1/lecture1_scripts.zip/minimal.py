#!/usr/bin/env python3

#Elementary Python program
print('Hello World!')

