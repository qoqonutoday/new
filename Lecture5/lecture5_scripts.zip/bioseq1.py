from Bio.Seq import Seq
from Bio.Alphabet.IUPAC import unambiguous_dna, ambiguous_dna


unamb_dna_seq = Seq("ACGT", unambiguous_dna)
ambig_dna_seq = Seq("ACRGT", ambiguous_dna)


print( unamb_dna_seq )
print( ambig_dna_seq.alphabet )

# A Seq object in python acts like a normal python string.

for letter in ambig_dna_seq:
    print( letter )

print( 'Length: ', len(ambig_dna_seq) )
print( ambig_dna_seq[4:12] )
print( ambig_dna_seq[::-1] )
print( str(ambig_dna_seq) )
